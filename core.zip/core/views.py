from django.shortcuts import render, redirect
from django import forms
from django.contrib.auth.models import User
from .model.game_model import Game
from django.contrib.auth.forms import UserCreationForm
from core.forms.game_form import GameForm

def register(request):
    # Логика для регистрации
    return render(request, 'core/register.html')

def login_view(request):
    # Логика для формы входа
    return render(request, 'core/login.html')

def user_list(request):
    users = User.objects.all()  # Получаем всех пользователей

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user_list')  # Перенаправление после добавления
    else:
        form = UserCreationForm()

    return render(request, 'core/users.html', {
        'users': users,
        'form': form
    })

def home(request):
    return render(request, 'core/home.html')

# Страница с играми
def game_list(request):
    query = request.GET.get('q', '')  # Получаем поисковый запрос из URL
    if query:
        # Фильтрация по имени или категории игры
        games = Game.objects.filter(title__icontains=query) | Game.objects.filter(genre__icontains=query)
    else:
        games = Game.objects.all()

    form = GameForm(request.POST or None)  # Форма для добавления новой игры
    # Пример, как можно изменить queryset в форме
    form.fields['user'].queryset = User.objects.filter(is_active=True)  # Пример фильтрации активных пользователей

    if request.method == 'POST' and form.is_valid():
        form.save()  # Сохраняем игру
        return redirect('game_list')  # Перезагружаем страницу с играми

    return render(request, 'core/games.html', {
        'games': games,
        'form': form,
        'query': query
    })
