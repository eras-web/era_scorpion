from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('games/', views.game_list, name='game_list'),
    path('users/', views.user_list, name='user_list'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register, name='register'),
]
