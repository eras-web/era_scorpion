
from django.contrib import admin
from django.urls import path
from core.route.user_view import user_list
from core.route.game_view import game_list
from django.urls import path, include  

urlpatterns = [
    path('admin/', admin.site.urls),  
    path('', include('core.urls')),   
]
